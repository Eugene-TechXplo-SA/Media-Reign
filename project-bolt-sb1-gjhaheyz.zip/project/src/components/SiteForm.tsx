import React, { useState } from 'react';
import { ArrowLeft, Save } from 'lucide-react';
import { Site } from '../types';

interface SiteFormProps {
  site?: Site | null;
  onSave: (site: Site) => void;
  onCancel: () => void;
}

export const SiteForm: React.FC<SiteFormProps> = ({ site, onSave, onCancel }) => {
  const [formData, setFormData] = useState<Partial<Site>>(
    site || {
      siteNo: '',
      city: '',
      province: '',
      location: '',
      address: '',
      gpsCoordinates: '',
      image: '',
      mapLink: '',
      kmzLink: '',
      size: '',
      numberOfPanels: 0,
      monthlyMediaRate: 0,
      discountedRate: 0,
      productionAndFlighting: '',
      registeredTaxis: 0,
      commutersPerDay: 0,
      commutersPerMonth: 0,
      siteDescription: '',
      anchorTenants: '',
    }
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.siteNo) return;
    
    onSave({
      ...formData,
      id: site?.id || '',
    } as Site);
  };

  const handleInputChange = (field: keyof Site, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const provinces = [
    'Gauteng', 'Western Cape', 'KwaZulu-Natal', 'Eastern Cape',
    'Free State', 'Limpopo', 'Mpumalanga', 'North West', 'Northern Cape'
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-lg p-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <button
              onClick={onCancel}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">
                {site ? 'Edit Site' : 'Add New Site'}
              </h2>
              <p className="text-gray-600">Fill in the site details below</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Site Details */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Basic Site Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Site No. <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.siteNo || ''}
                  onChange={(e) => handleInputChange('siteNo', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., MR/FAR-01 (HC)"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">City</label>
                <input
                  type="text"
                  value={formData.city || ''}
                  onChange={(e) => handleInputChange('city', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Johannesburg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Province</label>
                <select
                  value={formData.province || ''}
                  onChange={(e) => handleInputChange('province', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select Province</option>
                  {provinces.map(province => (
                    <option key={province} value={province}>{province}</option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                <input
                  type="text"
                  value={formData.location || ''}
                  onChange={(e) => handleInputChange('location', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Faraday Taxi Rank"
                />
              </div>

              <div className="md:col-span-3">
                <label className="block text-sm font-medium text-gray-700 mb-2">Address</label>
                <input
                  type="text"
                  value={formData.address || ''}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Cnr Eloff St & Wemmer Jubilee"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">GPS Coordinates</label>
                <input
                  type="text"
                  value={formData.gpsCoordinates || ''}
                  onChange={(e) => handleInputChange('gpsCoordinates', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder={"e.g., 26°12'45.54\"S, 28° 2'46.77\"E"}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Site Image URL</label>
                <input
                  type="url"
                  value={formData.image || ''}
                  onChange={(e) => handleInputChange('image', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="https://..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Map Link</label>
                <input
                  type="url"
                  value={formData.mapLink || ''}
                  onChange={(e) => handleInputChange('mapLink', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="https://..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">KMZ Link</label>
                <input
                  type="url"
                  value={formData.kmzLink || ''}
                  onChange={(e) => handleInputChange('kmzLink', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="https://..."
                />
              </div>
            </div>
          </div>

          {/* Media Details */}
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Media Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Size</label>
                <input
                  type="text"
                  value={formData.size || ''}
                  onChange={(e) => handleInputChange('size', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., 8.5m x 2.4m x 2.8m"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Number of Panels</label>
                <input
                  type="number"
                  value={formData.numberOfPanels || ''}
                  onChange={(e) => handleInputChange('numberOfPanels', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="4"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Monthly Media Rate (R)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.monthlyMediaRate || ''}
                  onChange={(e) => handleInputChange('monthlyMediaRate', parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Discounted Rate (R)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.discountedRate || ''}
                  onChange={(e) => handleInputChange('discountedRate', parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Production and Flighting</label>
                <input
                  type="text"
                  value={formData.productionAndFlighting || ''}
                  onChange={(e) => handleInputChange('productionAndFlighting', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* Traffic & Audience Data */}
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Traffic & Audience Data</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Registered Taxis</label>
                <input
                  type="number"
                  value={formData.registeredTaxis || ''}
                  onChange={(e) => handleInputChange('registeredTaxis', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="1500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Commuters per Day</label>
                <input
                  type="number"
                  value={formData.commutersPerDay || ''}
                  onChange={(e) => handleInputChange('commutersPerDay', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="252000"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Commuters per Month</label>
                <input
                  type="number"
                  value={formData.commutersPerMonth || ''}
                  onChange={(e) => handleInputChange('commutersPerMonth', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="6552000"
                />
              </div>
            </div>
          </div>

          {/* Additional Information */}
          <div className="bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Additional Information</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Site Description</label>
                <textarea
                  rows={4}
                  value={formData.siteDescription || ''}
                  onChange={(e) => handleInputChange('siteDescription', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Key rank and 4th busiest rank..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Anchor Tenants</label>
                <textarea
                  rows={3}
                  value={formData.anchorTenants || ''}
                  onChange={(e) => handleInputChange('anchorTenants', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Johannesburg Metro Police, Faraday Market, Spar, Shoprite, etc."
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={onCancel}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors shadow-lg"
            >
              <Save className="h-5 w-5" />
              <span>{site ? 'Update Site' : 'Save Site'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};