import React, { useState } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle } from 'lucide-react';
import { parsePowerPointTemplate, TemplateAnalysis } from '../utils/pptxParser';

interface TemplateUploadProps {
  selectedTemplate: File | null;
  setSelectedTemplate: (file: File | null) => void;
  onTemplateAnalyzed: (analysis: TemplateAnalysis) => void;
}

export const TemplateUpload: React.FC<TemplateUploadProps> = ({ 
  selectedTemplate, 
  setSelectedTemplate, 
  onTemplateAnalyzed 
}) => {
  const [analysisResult, setAnalysisResult] = useState<TemplateAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.includes('presentation')) {
      setSelectedTemplate(file);
      analyzeTemplate(file);
    }
  };

  const handleDrop = (event: React.DragEvent) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    if (file && file.type.includes('presentation')) {
      setSelectedTemplate(file);
      analyzeTemplate(file);
    }
  };

  const analyzeTemplate = async (file: File) => {
    setIsAnalyzing(true);
    setAnalysisError(null);
    
    try {
      const analysis = await parsePowerPointTemplate(file);
      setAnalysisResult(analysis);
      onTemplateAnalyzed(analysis);
      setIsAnalyzing(false);
    } catch (error) {
      console.error('Template analysis failed:', error);
      setAnalysisError(error instanceof Error ? error.message : 'Failed to analyze template');
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-800">Template Upload & Analysis</h2>
        <p className="text-gray-600 mt-2">Upload your PowerPoint template to detect placeholders and slide structure</p>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-8">
        {!selectedTemplate ? (
          <div 
            className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center hover:border-blue-400 transition-colors"
            onDrop={handleDrop}
            onDragOver={(e) => e.preventDefault()}
          >
            <Upload className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">Upload PowerPoint Template</h3>
            <p className="text-gray-500 mb-6">Drag and drop your .pptx file here, or click to browse</p>
            <label className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer inline-block">
              Choose File
              <input
                type="file"
                accept=".pptx,.ppt"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center space-x-4 p-4 bg-green-50 border border-green-200 rounded-lg">
              <FileText className="h-8 w-8 text-green-600" />
              <div>
                <h4 className="font-semibold text-green-800">{selectedTemplate.name}</h4>
                <p className="text-green-600 text-sm">{(selectedTemplate.size / 1024 / 1024).toFixed(2)} MB</p>
              </div>
              <button
                onClick={() => {
                  setSelectedTemplate(null);
                  setAnalysisResult(null);
                }}
                className="ml-auto text-green-600 hover:text-green-800"
              >
                Remove
              </button>
            </div>

            {isAnalyzing && (
              <div className="flex items-center justify-center space-x-3 p-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <span className="text-gray-600">Parsing PowerPoint file and detecting fields...</span>
              </div>
            )}

            {analysisError && (
              <div className="flex items-start space-x-3 p-4 bg-red-50 border border-red-200 rounded-lg">
                <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
                <div className="text-red-800">
                  <p className="font-medium">Analysis Failed</p>
                  <p className="text-sm mt-1">{analysisError}</p>
                </div>
              </div>
            )}

            {analysisResult && (
              <div className="space-y-6">
                <div className="flex items-center space-x-2 text-green-600">
                  <CheckCircle className="h-5 w-5" />
                  <span className="font-medium">Analysis Complete</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-blue-50 p-6 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Slides Detected</h4>
                    <p className="text-3xl font-bold text-blue-600">{analysisResult.slideCount}</p>
                  </div>
                  
                  <div className="bg-green-50 p-6 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Field Types</h4>
                    <p className="text-3xl font-bold text-green-600">
                      {Array.from(new Set(analysisResult.slides.flatMap(slide => slide.fields.map(f => f.fieldName)))).length}
                    </p>
                  </div>
                  
                  <div className="bg-purple-50 p-6 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Placeholders</h4>
                    <p className="text-3xl font-bold text-purple-600">
                      {analysisResult.slides.reduce((acc: number, slide: any) => acc + slide.fields.length, 0)}
                    </p>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-800 mb-4">Detected Field Types</h4>
                  <div className="flex flex-wrap gap-2">
                    {Array.from(new Set(analysisResult.slides.flatMap(slide => slide.fields.map(f => f.fieldName)))).map((field: string, index: number) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-white border border-gray-200 rounded-full text-sm text-gray-700"
                      >
                        {field}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-800 mb-4">Slide Structure</h4>
                  <div className="space-y-3">
                    {analysisResult.slides.map((slide) => (
                      <div key={slide.slideNumber} className="flex items-center space-x-4 p-3 bg-white rounded-lg border">
                        <div className="font-medium text-gray-700 min-w-0">
                          Slide {slide.slideNumber}
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {slide.fields.map((field, index: number) => (
                            <span
                              key={index}
                              className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs"
                            >
                              {field.fieldName}
                            </span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-start space-x-3 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
                  <div className="text-yellow-800">
                    <p className="font-medium">Ready for Mapping</p>
                    <p className="text-sm mt-1">
                      Your template has been analyzed successfully. You can now proceed to the Slide Mapping section to assign site data to each slide.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};