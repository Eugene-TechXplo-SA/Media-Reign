import React, { useState } from 'react';
import { Plus, Edit3, Trash2, Search, MapPin } from 'lucide-react';
import { Site } from '../types';
import { SiteForm } from './SiteForm';

interface SiteManagementProps {
  sites: Site[];
  setSites: (sites: Site[]) => void;
}

export const SiteManagement: React.FC<SiteManagementProps> = ({ sites, setSites }) => {
  const [showForm, setShowForm] = useState(false);
  const [editingSite, setEditingSite] = useState<Site | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSites = sites.filter(site =>
    site.siteNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    site.location?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    site.city?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddSite = (site: Site) => {
    setSites([...sites, { ...site, id: Date.now().toString() }]);
    setShowForm(false);
  };

  const handleEditSite = (site: Site) => {
    setSites(sites.map(s => s.id === site.id ? site : s));
    setEditingSite(null);
    setShowForm(false);
  };

  const handleDeleteSite = (id: string) => {
    setSites(sites.filter(s => s.id !== id));
  };

  if (showForm || editingSite) {
    return (
      <SiteForm
        site={editingSite}
        onSave={editingSite ? handleEditSite : handleAddSite}
        onCancel={() => {
          setShowForm(false);
          setEditingSite(null);
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-800">Site Management</h2>
          <p className="text-gray-600 mt-2">Manage all advertising site data and information</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors shadow-lg"
        >
          <Plus className="h-5 w-5" />
          <span>Add New Site</span>
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center space-x-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search by site number, location, or city..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="text-sm text-gray-500">
            {filteredSites.length} site{filteredSites.length !== 1 ? 's' : ''}
          </div>
        </div>

        {filteredSites.length === 0 ? (
          <div className="text-center py-12">
            <MapPin className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No sites found</h3>
            <p className="text-gray-500 mb-4">Get started by adding your first advertising site</p>
            <button
              onClick={() => setShowForm(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Add New Site
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSites.map((site) => (
              <div key={site.id} className="bg-gradient-to-br from-white to-gray-50 border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-all duration-300">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-bold text-lg text-gray-800">{site.siteNo}</h3>
                    <p className="text-gray-600 text-sm">{site.location}</p>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => setEditingSite(site)}
                      className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    >
                      <Edit3 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteSite(site.id)}
                      className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  {site.city && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">City:</span>
                      <span className="font-medium">{site.city}</span>
                    </div>
                  )}
                  {site.size && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Size:</span>
                      <span className="font-medium">{site.size}</span>
                    </div>
                  )}
                  {site.numberOfPanels && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Panels:</span>
                      <span className="font-medium">{site.numberOfPanels}</span>
                    </div>
                  )}
                  {site.commutersPerDay && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Daily Traffic:</span>
                      <span className="font-medium">{site.commutersPerDay.toLocaleString()}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};