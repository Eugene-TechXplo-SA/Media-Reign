import React, { useState } from 'react';
import { Download, CheckCircle, Clock, FileText } from 'lucide-react';
import { Site } from '../types';
import { TemplateAnalysis, generateMockPowerPoint } from '../utils/pptxParser';

interface ExportEngineProps {
  slideMapping: Record<number, { siteId: string; customData: Record<string, any> }>;
  sites: Site[];
  templateAnalysis: TemplateAnalysis | null;
}

export const ExportEngine: React.FC<ExportEngineProps> = ({ slideMapping, sites, templateAnalysis }) => {
  const [isExporting, setIsExporting] = useState(false);
  const [exportComplete, setExportComplete] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [generatedFile, setGeneratedFile] = useState<Blob | null>(null);

  const handleExport = async () => {
    if (!templateAnalysis) {
      alert('No template analysis available. Please upload and analyze a template first.');
      return;
    }

    setIsExporting(true);
    setExportProgress(0);

    // Simulate export progress
    const progressSteps = [
      { step: 25, message: 'Preparing slide templates...' },
      { step: 50, message: 'Injecting site data into slides...' },
      { step: 75, message: 'Preserving original formatting...' },
      { step: 100, message: 'Export complete!' }
    ];

    for (const { step, message } of progressSteps) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setExportProgress(step);
    }

    // Generate the PowerPoint file
    try {
      const pptxBlob = generateMockPowerPoint(templateAnalysis.slides, sites);
      setGeneratedFile(pptxBlob);
    } catch (error) {
      console.error('Error generating PowerPoint:', error);
      alert('Failed to generate PowerPoint file. Please try again.');
    }

    setIsExporting(false);
    setExportComplete(true);
  };

  const handleDownload = () => {
    if (generatedFile) {
      const url = URL.createObjectURL(generatedFile);
      const element = document.createElement('a');
      element.href = url;
      element.download = 'media-reign-presentation.pptx';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
      URL.revokeObjectURL(url);
    }
  };

  const mappedSlidesCount = Object.keys(slideMapping).length;
  const totalSlides = templateAnalysis?.slideCount || 0;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-800">Export Engine</h2>
        <p className="text-gray-600 mt-2">Generate and download your customized PowerPoint presentation</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Export Configuration */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-6">Export Configuration</h3>

          <div className="space-y-6">
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4">
              <h4 className="font-medium text-blue-800 mb-3">Presentation Summary</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-blue-600">Total Slides:</span>
                  <div className="font-semibold text-blue-800">{totalSlides}</div>
                </div>
                <div>
                  <span className="text-blue-600">Mapped Slides:</span>
                  <div className="font-semibold text-blue-800">{mappedSlidesCount}</div>
                </div>
                <div>
                  <span className="text-blue-600">Template:</span>
                  <div className="font-semibold text-blue-800">{templateAnalysis?.fileName || 'No template'}</div>
                </div>
                <div>
                  <span className="text-blue-600">Format:</span>
                  <div className="font-semibold text-blue-800">PowerPoint (.pptx)</div>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium text-gray-700">Export Options</h4>
              <div className="space-y-2">
                <label className="flex items-center space-x-3">
                  <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
                  <span className="text-sm text-gray-700">Preserve original formatting</span>
                </label>
                <label className="flex items-center space-x-3">
                  <input type="checkbox" defaultChecked className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
                  <span className="text-sm text-gray-700">Include site images</span>
                </label>
                <label className="flex items-center space-x-3">
                  <input type="checkbox" className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
                  <span className="text-sm text-gray-700">Generate speaker notes</span>
                </label>
                <label className="flex items-center space-x-3">
                  <input type="checkbox" className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" />
                  <span className="text-sm text-gray-700">Create backup copy</span>
                </label>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-gray-700 mb-3">File Settings</h4>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm text-gray-600 mb-1">File Name</label>
                  <input
                    type="text"
                    defaultValue="media-reign-presentation"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-600 mb-1">Quality</label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option>High Quality</option>
                    <option>Medium Quality</option>
                    <option>Low Quality (Faster)</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Export Progress */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-6">Export Status</h3>

          {!isExporting && !exportComplete && (
            <div className="text-center space-y-6">
              <div className="bg-gray-50 rounded-lg p-8">
                <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h4 className="text-lg font-medium text-gray-700 mb-2">Ready to Export</h4>
                <p className="text-gray-500 text-sm">
                  Your presentation is configured and ready to be generated. 
                  Click the export button to create your PowerPoint file.
                </p>
              </div>
              
              <button
                onClick={handleExport}
                className="flex items-center justify-center space-x-2 bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors shadow-lg w-full"
                disabled={mappedSlidesCount === 0}
              >
                <Download className="h-5 w-5" />
                <span>Generate Presentation</span>
              </button>
              
              {mappedSlidesCount === 0 && (
                <p className="text-sm text-gray-500 text-center">
                  Please map at least one slide before exporting
                </p>
              )}
            </div>
          )}

          {isExporting && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="bg-blue-50 rounded-lg p-6 mb-4">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                  <h4 className="text-lg font-medium text-blue-800">Generating Presentation</h4>
                  <p className="text-blue-600 text-sm mt-1">Please wait while we process your data...</p>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Progress</span>
                  <span className="font-medium text-gray-800">{exportProgress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300 ease-out"
                    style={{ width: `${exportProgress}%` }}
                  ></div>
                </div>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2 text-gray-600">
                  <Clock className="h-4 w-4" />
                  <span>Processing slides and data injection...</span>
                </div>
              </div>
            </div>
          )}

          {exportComplete && (
            <div className="text-center space-y-6">
              <div className="bg-green-50 rounded-lg p-8">
                <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
                <h4 className="text-lg font-medium text-green-800 mb-2">Export Complete!</h4>
                <p className="text-green-700 text-sm">
                  Your PowerPoint presentation has been generated successfully. 
                  You can now download the file.
                </p>
              </div>

              <div className="space-y-3">
                <button
                  onClick={handleDownload}
                  className="flex items-center justify-center space-x-2 bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors shadow-lg w-full"
                >
                  <Download className="h-5 w-5" />
                  <span>Download Presentation</span>
                </button>

                <button
                  onClick={() => {
                    setExportComplete(false);
                    setExportProgress(0);
                  }}
                  className="text-gray-600 hover:text-gray-800 text-sm"
                >
                  Generate Another
                </button>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-left">
                <h5 className="font-medium text-blue-800 mb-2">File Details</h5>
                <div className="space-y-1 text-sm text-blue-700">
                  <div>Filename: media-reign-presentation.pptx</div>
                  <div>Size: {generatedFile ? `${(generatedFile.size / 1024).toFixed(1)} KB` : 'Unknown'}</div>
                  <div>Slides: {totalSlides}</div>
                  <div>Mapped: {mappedSlidesCount}</div>
                  <div>Generated: {new Date().toLocaleString()}</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {mappedSlidesCount > 0 && (
        <div className="bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl p-6">
          <h4 className="font-semibold text-gray-800 mb-4">Mapped Slides Summary</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.entries(slideMapping).slice(0, 4).map(([slideNumber, mapping]) => {
              const site = sites.find(s => s.id === mapping.siteId);
              return (
                <div key={slideNumber} className="bg-white rounded-lg p-4 border border-gray-200">
                  <div className="font-medium text-gray-800">Slide {slideNumber}</div>
                  <div className="text-sm text-gray-600">{site?.siteNo || 'Unknown Site'}</div>
                  <div className="text-xs text-gray-500 mt-1">
                    {site?.location || 'No location'}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};