import React, { useState } from 'react';
import { Site } from '../types';
import { ChevronLeft, ChevronRight, Eye, Edit3 } from 'lucide-react';
import { TemplateAnalysis } from '../utils/pptxParser';

interface SlideMappingProps {
  sites: Site[];
  selectedTemplate: File | null;
  templateAnalysis: TemplateAnalysis | null;
  slideMapping: Record<number, { siteId: string; customData: Record<string, any> }>;
  setSlideMapping: (mapping: Record<number, { siteId: string; customData: Record<string, any> }>) => void;
}

export const SlideMapping: React.FC<SlideMappingProps> = ({ 
  sites, 
  selectedTemplate, 
  templateAnalysis,
  slideMapping, 
  setSlideMapping 
}) => {
  const [currentSlide, setCurrentSlide] = useState(1);

  if (!selectedTemplate || !templateAnalysis) {
    return (
      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-gray-800">Slide Mapping</h2>
        <div className="bg-white rounded-xl shadow-lg p-12 text-center">
          <div className="text-gray-400 mb-4">
            <svg className="h-16 w-16 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
          <h3 className="text-xl font-semibold text-gray-700 mb-2">No Template Uploaded</h3>
          <p className="text-gray-500">Please upload a PowerPoint template first to proceed with slide mapping</p>
        </div>
      </div>
    );
  }

  const currentSlideData = templateAnalysis.slides.find(slide => slide.slideNumber === currentSlide);
  const currentMapping = slideMapping[currentSlide];
  const selectedSiteData = currentMapping ? sites.find(site => site.id === currentMapping.siteId) : null;

  const handleSiteSelection = (siteId: string) => {
    const site = sites.find(s => s.id === siteId);
    if (site && currentSlideData) {
      const autoData: Record<string, any> = {};
      currentSlideData.fields.forEach(field => {
        switch (field.fieldName) {
          case 'Site No.': autoData[field] = site.siteNo; break;
          case 'Location': autoData[field] = site.location; break;
          case 'City': autoData[field] = site.city; break;
          case 'Province': autoData[field] = site.province; break;
          case 'Address': autoData[field] = site.address; break;
          case 'Description': autoData[field] = site.siteDescription; break;
          case 'Size': autoData[field] = site.size; break;
          case 'Number of Panels': autoData[field] = site.numberOfPanels; break;
          case 'Monthly Media Rate': autoData[field] = site.monthlyMediaRate; break;
          case 'Discounted Rate': autoData[field] = site.discountedRate; break;
          case 'Production and Flighting': autoData[field] = site.productionAndFlighting; break;
          case 'GPS Coordinates': autoData[field] = site.gpsCoordinates; break;
          case 'Registered Taxis': autoData[field] = site.registeredTaxis; break;
          case 'Commuters per Day': autoData[field] = site.commutersPerDay; break;
          case 'Commuters per Month': autoData[field] = site.commutersPerMonth; break;
          case 'KMZ Link': autoData[field] = site.kmzLink; break;
          case 'Map Link': autoData[field] = site.mapLink; break;
          case 'Anchor Tenants': autoData[field] = site.anchorTenants; break;
          case 'Image': autoData[field] = site.image || 'https://images.pexels.com/photos/7846019/pexels-photo-7846019.jpeg?auto=compress&cs=tinysrgb&w=800'; break;
        }
      });
      
      setSlideMapping({
        ...slideMapping,
        [currentSlide]: {
          siteId,
          customData: autoData
        }
      });
    }
  };

  const handleFieldChange = (fieldName: string, value: any) => {
    if (currentMapping) {
      setSlideMapping({
        ...slideMapping,
        [currentSlide]: {
          ...currentMapping,
          customData: {
            ...currentMapping.customData,
            [fieldName]: value
          }
        }
      });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-800">Slide Mapping</h2>
        <p className="text-gray-600 mt-2">Assign site data to slide fields and preview the results</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Slide Navigation */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="font-semibold text-gray-800 mb-4">Slides</h3>
          <div className="space-y-2">
            {templateAnalysis.slides.map((slide) => (
              <button
                key={slide.slideNumber}
                onClick={() => setCurrentSlide(slide.slideNumber)}
                className={`w-full text-left p-3 rounded-lg transition-colors ${
                  currentSlide === slide.slideNumber
                    ? 'bg-blue-50 border border-blue-200 text-blue-700'
                    : 'hover:bg-gray-50 text-gray-600'
                }`}
              >
                <div className="font-medium">Slide {slide.slideNumber}</div>
                <div className="text-sm opacity-75">{slide.fields.length} fields</div>
              </button>
            ))}
          </div>
        </div>

        {/* Slide Configuration */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-800">Slide {currentSlide} Configuration</h3>
            <div className="flex space-x-2">
              <button
                onClick={() => setCurrentSlide(Math.max(1, currentSlide - 1))}
                disabled={currentSlide === 1}
                className="p-2 text-gray-400 hover:text-gray-600 disabled:opacity-50"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <button
                onClick={() => setCurrentSlide(Math.min(templateAnalysis.slides.length, currentSlide + 1))}
                disabled={currentSlide === templateAnalysis.slides.length}
                className="p-2 text-gray-400 hover:text-gray-600 disabled:opacity-50"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Assign Site</label>
              <select
                value={currentMapping?.siteId || ''}
                onChange={(e) => handleSiteSelection(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Select a site</option>
                {sites.map((site) => (
                  <option key={site.id} value={site.id}>
                    {site.siteNo} - {site.location}
                  </option>
                ))}
              </select>
            </div>

            {selectedSiteData && currentSlideData && (
              <div className="space-y-3">
                <h4 className="font-medium text-gray-700">Field Mapping</h4>
                {currentSlideData.fields.map((field) => (
                  <div key={field.fieldName}>
                    <label className="block text-sm text-gray-600 mb-1">{field.fieldName}</label>
                    <input
                      type="text"
                      value={currentMapping?.customData[field.fieldName] || ''}
                      onChange={(e) => handleFieldChange(field.fieldName, e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                      placeholder={`Enter ${field.fieldName.toLowerCase()}...`}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Preview Panel */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Eye className="h-5 w-5 text-blue-600" />
            <h3 className="font-semibold text-gray-800">Slide Preview</h3>
          </div>

          <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg p-6 text-white aspect-video">
            <div className="h-full flex flex-col justify-between">
              <div>
                <h4 className="text-xl font-bold mb-2">
                  {currentMapping?.customData['Site No.'] || 'Site Number'}
                </h4>
                <p className="text-blue-100 text-sm">
                  {currentMapping?.customData['Location'] || 'Location will appear here'}
                </p>
              </div>
              
              {currentSlideData?.fields.some(f => f.fieldName === 'Site Description') && (
                <div className="bg-white/10 rounded p-3 backdrop-blur">
                  <p className="text-sm">
                    {currentMapping?.customData['Site Description'] || 'Site description will appear here...'}
                  </p>
                </div>
              )}

              {currentSlideData?.fields.some(f => f.fieldName === 'Commuters per Day') && (
                <div className="text-right">
                  <div className="text-2xl font-bold">
                    {currentMapping?.customData['Commuters per Day'] ? 
                      Number(currentMapping.customData['Commuters per Day']).toLocaleString() : 
                      '0'
                    }
                  </div>
                  <div className="text-blue-100 text-sm">Commuters per Day</div>
                </div>
              )}
            </div>
          </div>

          <div className="mt-4 space-y-2 text-sm">
            {currentSlideData?.fields.map((field) => (
              <div key={field.fieldName} className="flex justify-between">
                <span className="text-gray-500">{field.fieldName}:</span>
                <span className="text-gray-700 truncate ml-2">
                  {currentMapping?.customData[field.fieldName] || 'Not set'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Edit3 className="h-5 w-5 text-blue-600 mt-0.5" />
          <div className="text-blue-800">
            <p className="font-medium">Mapping Progress</p>
            <p className="text-sm mt-1">
              Configure each slide by selecting one site per slide and reviewing the auto-populated fields. 
              You can edit any field value before proceeding to export.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};