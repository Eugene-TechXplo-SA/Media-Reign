export interface Site {
  id: string;
  siteNo: string;
  city?: string;
  province?: string;
  location?: string;
  address?: string;
  gpsCoordinates?: string;
  image?: string;
  mapLink?: string;
  kmzLink?: string;
  size?: string;
  numberOfPanels?: number;
  monthlyMediaRate?: number;
  discountedRate?: number;
  productionAndFlighting?: string;
  registeredTaxis?: number;
  commutersPerDay?: number;
  commutersPerMonth?: number;
  siteDescription?: string;
  anchorTenants?: string;
}

export interface SlideField {
  fieldName: string;
  fieldType: string;
  required: boolean;
}

export interface SlideTemplate {
  slideNumber: number;
  fields: SlideField[];
  assignedSiteId?: string;
  customData?: Record<string, any>;
}

export interface TemplateAnalysis {
  slideCount: number;
  slides: SlideTemplate[];
}