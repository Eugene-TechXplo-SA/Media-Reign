import JSZip from 'jszip';
import { parseString } from 'xml2js';

export interface SlideField {
  fieldName: string;
  fieldType: string;
  required: boolean;
}

export interface SlideTemplate {
  slideNumber: number;
  fields: SlideField[];
  assignedSiteId?: string;
  customData?: Record<string, any>;
}

export interface TemplateAnalysis {
  slideCount: number;
  slides: SlideTemplate[];
  fileName: string;
}

// Common field patterns to detect in PowerPoint slides
const FIELD_PATTERNS = [
  { pattern: /site\s*no\.?/i, fieldName: 'Site No.', fieldType: 'text' },
  { pattern: /location/i, fieldName: 'Location', fieldType: 'text' },
  { pattern: /city/i, fieldName: 'City', fieldType: 'text' },
  { pattern: /province/i, fieldName: 'Province', fieldType: 'text' },
  { pattern: /address/i, fieldName: 'Address', fieldType: 'text' },
  { pattern: /gps|coordinates/i, fieldName: 'GPS Coordinates', fieldType: 'text' },
  { pattern: /image|photo|picture/i, fieldName: 'Image', fieldType: 'image' },
  { pattern: /map/i, fieldName: 'Map Link', fieldType: 'url' },
  { pattern: /kmz/i, fieldName: 'KMZ Link', fieldType: 'url' },
  { pattern: /size/i, fieldName: 'Size', fieldType: 'text' },
  { pattern: /panels?/i, fieldName: 'Number of Panels', fieldType: 'number' },
  { pattern: /media\s*rate|monthly\s*rate/i, fieldName: 'Monthly Media Rate', fieldType: 'currency' },
  { pattern: /discount/i, fieldName: 'Discounted Rate', fieldType: 'currency' },
  { pattern: /production|flighting/i, fieldName: 'Production and Flighting', fieldType: 'text' },
  { pattern: /taxis?/i, fieldName: 'Registered Taxis', fieldType: 'number' },
  { pattern: /commuters?\s*per\s*day|daily\s*commuters?/i, fieldName: 'Commuters per Day', fieldType: 'number' },
  { pattern: /commuters?\s*per\s*month|monthly\s*commuters?/i, fieldName: 'Commuters per Month', fieldType: 'number' },
  { pattern: /description/i, fieldName: 'Site Description', fieldType: 'textarea' },
  { pattern: /anchor\s*tenants?/i, fieldName: 'Anchor Tenants', fieldType: 'textarea' },
];

export async function parsePowerPointTemplate(file: File): Promise<TemplateAnalysis> {
  try {
    const zip = new JSZip();
    const zipContent = await zip.loadAsync(file);
    
    // Get presentation.xml to find slide count
    const presentationXml = await zipContent.file('ppt/presentation.xml')?.async('string');
    if (!presentationXml) {
      throw new Error('Invalid PowerPoint file: presentation.xml not found');
    }

    // Parse presentation.xml to get slide references
    const slideRefs = await parseSlideReferences(presentationXml);
    const slideCount = slideRefs.length;

    // Parse each slide to detect fields
    const slides: SlideTemplate[] = [];
    
    for (let i = 0; i < slideCount; i++) {
      const slideNumber = i + 1;
      const slideFileName = `ppt/slides/slide${slideNumber}.xml`;
      
      try {
        const slideXml = await zipContent.file(slideFileName)?.async('string');
        if (slideXml) {
          const fields = await parseSlideFields(slideXml);
          slides.push({
            slideNumber,
            fields,
            assignedSiteId: undefined,
            customData: {}
          });
        } else {
          // If slide file doesn't exist, create empty slide
          slides.push({
            slideNumber,
            fields: [],
            assignedSiteId: undefined,
            customData: {}
          });
        }
      } catch (error) {
        console.warn(`Could not parse slide ${slideNumber}:`, error);
        // Create empty slide if parsing fails
        slides.push({
          slideNumber,
          fields: [],
          assignedSiteId: undefined,
          customData: {}
        });
      }
    }

    return {
      slideCount,
      slides,
      fileName: file.name
    };
  } catch (error) {
    console.error('Error parsing PowerPoint file:', error);
    throw new Error('Failed to parse PowerPoint file. Please ensure it is a valid .pptx file.');
  }
}

async function parseSlideReferences(presentationXml: string): Promise<string[]> {
  return new Promise((resolve, reject) => {
    parseString(presentationXml, (err, result) => {
      if (err) {
        reject(err);
        return;
      }

      try {
        const slideIdList = result?.['p:presentation']?.['p:sldIdLst']?.[0]?.['p:sldId'] || [];
        const slideRefs = slideIdList.map((slide: any) => slide.$['r:id']);
        resolve(slideRefs);
      } catch (error) {
        reject(error);
      }
    });
  });
}

async function parseSlideFields(slideXml: string): Promise<SlideField[]> {
  return new Promise((resolve, reject) => {
    parseString(slideXml, (err, result) => {
      if (err) {
        reject(err);
        return;
      }

      try {
        const fields: SlideField[] = [];
        const detectedFields = new Set<string>();

        // Extract all text content from the slide
        const textContent = extractTextFromSlide(result);
        
        // Match against known field patterns
        FIELD_PATTERNS.forEach(({ pattern, fieldName, fieldType }) => {
          if (pattern.test(textContent) && !detectedFields.has(fieldName)) {
            fields.push({
              fieldName,
              fieldType,
              required: false
            });
            detectedFields.add(fieldName);
          }
        });

        // If no fields detected, add some default ones
        if (fields.length === 0) {
          fields.push(
            { fieldName: 'Site No.', fieldType: 'text', required: false },
            { fieldName: 'Location', fieldType: 'text', required: false },
            { fieldName: 'Image', fieldType: 'image', required: false }
          );
        }

        resolve(fields);
      } catch (error) {
        reject(error);
      }
    });
  });
}

function extractTextFromSlide(slideData: any): string {
  let textContent = '';
  
  function extractText(obj: any) {
    if (typeof obj === 'string') {
      textContent += obj + ' ';
    } else if (Array.isArray(obj)) {
      obj.forEach(extractText);
    } else if (obj && typeof obj === 'object') {
      Object.values(obj).forEach(extractText);
    }
  }
  
  extractText(slideData);
  return textContent.toLowerCase();
}

export function generateMockPowerPoint(slides: SlideTemplate[], sites: any[]): Blob {
  // This is a mock implementation - in a real application, you would use a library
  // like PptxGenJS or similar to generate actual PowerPoint files
  
  const mockPptxContent = {
    metadata: {
      title: 'Media Reign Presentation',
      author: 'Media Reign System',
      created: new Date().toISOString()
    },
    slides: slides.map(slide => ({
      slideNumber: slide.slideNumber,
      assignedSite: sites.find(site => site.id === slide.assignedSiteId),
      fields: slide.fields,
      customData: slide.customData
    }))
  };

  // Create a mock file blob
  const jsonContent = JSON.stringify(mockPptxContent, null, 2);
  return new Blob([jsonContent], { 
    type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation' 
  });
}