import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { SiteManagement } from './components/SiteManagement';
import { TemplateUpload } from './components/TemplateUpload';
import { SlideMapping } from './components/SlideMapping';
import { ExportEngine } from './components/ExportEngine';
import { Site } from './types';
import { TemplateAnalysis } from './utils/pptxParser';

function App() {
  const [currentPage, setCurrentPage] = useState('sites');
  const [sites, setSites] = useState<Site[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<File | null>(null);
  const [templateAnalysis, setTemplateAnalysis] = useState<TemplateAnalysis | null>(null);
  const [slideMapping, setSlideMapping] = useState<Record<number, { siteId: string; customData: Record<string, any> }>>({});

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'sites':
        return <SiteManagement sites={sites} setSites={setSites} />;
      case 'template':
        return (
          <TemplateUpload 
            setSelectedTemplate={setSelectedTemplate} 
            selectedTemplate={selectedTemplate}
            onTemplateAnalyzed={setTemplateAnalysis}
          />
        );
      case 'mapping':
        return (
          <SlideMapping 
            sites={sites} 
            selectedTemplate={selectedTemplate} 
            templateAnalysis={templateAnalysis}
            slideMapping={slideMapping} 
            setSlideMapping={setSlideMapping} 
          />
        );
      case 'export':
        return (
          <ExportEngine 
            slideMapping={slideMapping} 
            sites={sites} 
            templateAnalysis={templateAnalysis}
          />
        );
      default:
        return <SiteManagement sites={sites} setSites={setSites} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Navigation currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <main className="container mx-auto px-4 py-8">
        {renderCurrentPage()}
      </main>
    </div>
  );
}

export default App;